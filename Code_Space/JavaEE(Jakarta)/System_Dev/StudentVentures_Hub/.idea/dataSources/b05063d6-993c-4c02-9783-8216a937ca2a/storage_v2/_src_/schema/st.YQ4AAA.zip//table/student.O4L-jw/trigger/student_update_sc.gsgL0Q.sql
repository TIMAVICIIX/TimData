create definer = root@localhost trigger student_update_sc
    after update
    on student
    for each row
BEGIN
    DECLARE newsno CHAR(10);
    DECLARE oldsno CHAR(10);
    SET newsno=new.sno;
    SET oldsno=old.sno;
    IF newsno<>oldsno THEN
	UPDATE sc SET sno=newsno WHERE sno=oldsno;
    END IF;
    END;

