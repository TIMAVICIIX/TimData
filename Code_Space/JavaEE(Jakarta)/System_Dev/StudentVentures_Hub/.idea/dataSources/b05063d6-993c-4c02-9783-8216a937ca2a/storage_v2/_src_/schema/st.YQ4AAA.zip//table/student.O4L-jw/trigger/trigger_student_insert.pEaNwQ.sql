create definer = root@localhost trigger trigger_student_insert
    before insert
    on student
    for each row
BEGIN
    DECLARE dsex CHAR(5);
    declare dage smallint;
    declare chiose int;
    set dage =new.sage;
    set dsex =new.ssex;
	if(dage>15 and dage<41)and(dsex='M'or dsex='F') then
		set chiose=1;
	else
		set chiose=0;
		insert into student(sage,ssex) values(dage,dsex);
	end if;
        END;

