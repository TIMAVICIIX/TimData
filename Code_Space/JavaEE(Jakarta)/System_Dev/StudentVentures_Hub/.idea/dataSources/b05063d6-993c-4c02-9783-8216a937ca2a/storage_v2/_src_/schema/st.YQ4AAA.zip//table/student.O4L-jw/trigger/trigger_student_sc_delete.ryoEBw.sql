create definer = root@localhost trigger trigger_student_sc_delete
    after delete
    on student
    for each row
BEGIN
    DECLARE oldsno CHAR(10);
    SET oldsno=old.sno;
	delete from sc where sno=oldsno;
    
    END;

