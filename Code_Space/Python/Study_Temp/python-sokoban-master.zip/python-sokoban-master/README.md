## python实现推箱子小游戏

### 依赖pygame
> pip install pygame

### 运行
> python.exe main.py

### 键盘操作
+ 上下左右键
+ wsad键同上